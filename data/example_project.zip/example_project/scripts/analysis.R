# Necessary R packages
library(ggplot2)

# Read in data
amphibians_clean = read.csv("clean_data/amphibians_clean.csv")
toads_mass = read.csv("clean_data/toads_mass.csv")

# Plot amphibian locations
ggplot(data = amphibians_clean, aes(x = longitude, y = latitude)) +
  borders("world") +
  geom_point(size = .5, color = "blue") +
  theme_bw()

# Plot latitude-mass relationship
ggplot(data = amphibians_clean, aes(x = latitude, y = mass)) +
  geom_point() +
  geom_vline(xintercept = 0, color = "red") +
  scale_y_log10()

# Plot average species mass for toads
ggplot(data = toads_mass, aes(x = genusspecies, y = mean_mass)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle = 90))

# Save plots
ggsave("figures/toads_mass.png")
