# Run all scripts in order
source("scripts/cleaning.R")
source("scripts/analysis.R")
