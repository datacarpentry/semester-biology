# Necessary R packages
library(dplyr)

# Read in museum data
amphibians = read.csv("raw_data/amphibian_specimens.csv")

# Clean museum data
amphibians_clean = amphibians %>%
  select(-c(X.1, X, X1)) %>%
  filter(isfossil == 0, genusspecies != "Bolitoglossa subpalmata", year > 2005)

toads_mass = amphibians_clean %>%
  group_by(family, genusspecies) %>% 
  summarize(mean_mass = mean(mass)) %>% 
  filter(family == "Bufonidae")

# Save clean data
write.csv(amphibians_clean, "clean_data/amphibians_clean.csv")
write.csv(toads_mass, "clean_data/toads_mass.csv")
