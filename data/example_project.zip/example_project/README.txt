Project purpose: to explore individual masses of amphibians visually

To rerun all scripts that generate clean data files and figures, install necessary R packages and run “run_all.R” in scripts folder. 

R packages: 
dplyr
ggplot2

Files in order of use: 
1. raw_data/amphibian_specimens.csv - raw data file with amphibian individual masses
2. raw_data/metadata.docx - file describing amphibian_specimens.csv

3. scripts/cleaning.R - code to clean up raw data, produces two following data files
4. clean_data/amphibians_clean.csv - amphibian individual masses data with extra row number files removed, fossil specimens removed, La Palma salamander records removed (because mass values are erroneous), including only data collected starting in 2005
5. clean_data/toads_mass.csv - previous data file, with mean mass for each species in the Bufonidae family

6. scripts/analysis.R - code to produce figures from two cleaned data files
7. figures/toads_mass.png - only figure produced from analysis script

8. documents/manuscript.docx - draft of manuscript describing project and findings