library(raster)
library(ggplot2)

original <- raster("HARV/HARV_dsmCrop.tif")
original
smaller <- aggregate(original, 2)
res(original)
res(smaller)
smaller
plot(smaller)
writeRaster(smaller, "HARV/HARV_dsmCrop.tif", overwrite = TRUE)
